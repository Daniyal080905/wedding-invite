# Wedding Invite

Что менять:
- index.html — имена, дата, адрес, текст
- script.js — дата таймера
- папка images — фото

Нужные фото:
- images/photo1.jpg
- images/photo2.jpg
- images/photo3.jpg
- images/photo4.jpg

Как выложить:
1. Открой свой репозиторий GitHub.
2. Нажми Add file -> Upload files.
3. Перетащи все файлы из этой папки.
4. Нажми Commit changes.
5. В Settings -> Pages оставь:
   - Deploy from a branch
   - main
   - /(root)

Сайт будет доступен по адресу:
https://Daniyal080905.github.io/wedding-invite/
